package info.itest.www.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Created by eason on 2017/8/15.
 */
public class EditPostPage {

    @FindBy(id = "title")
    private WebElement postTitle;

    @FindBy(id = "publish")
    private WebElement publishBtn;

    public void createPost(String title, String content, WebDriver dr) {
        postTitle.sendKeys(title);
        setContent(dr, content);
        publishBtn.click();
    }

    public String createPostReturnID(String title, String content, WebDriver dr) {
        createPost(title, content, dr);
        String linkText = dr.findElement(By.id("sample-permalink")).getText();
        return linkText.split("=")[1];
    }

    public void setContent(WebDriver dr, String content) {
        String js = String.format("document.getElementById('content_ifr').contentWindow.document.body.innerHTML = '%s'",
                content);

        ((JavascriptExecutor)dr).executeScript(js);
    }

}
