package info.itest;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by eason on 2017/7/4.
 */
public class BaiduWeather {

    private String city;
    private WebDriver dr;
    private String baiduURL = "http://www.baidu.com";
    private By weatherBlockLocator = By.className("op_weather4_twoicon_container_div");

    public BaiduWeather(String city) {
        this.city = city;
        dr = new ChromeDriver();
        searchWeahterByCity();
    }

    private void searchWeahterByCity () {
        String keyword = this.city.concat("天气");
        dr.get(baiduURL);
        dr.findElement(By.id("kw")).sendKeys(keyword);
        WebDriverWait wait = new WebDriverWait(this.dr, 3);
        wait.until( ExpectedConditions.presenceOfElementLocated(this.weatherBlockLocator));
    }

    public WebElement weatherBlock() {
        return dr.findElement(weatherBlockLocator);
    }

    public WebElement todayBlock() {
        return weatherBlock().findElement(By.cssSelector(".op_weather4_twoicon_today"));
    }


    public WebElement tomorrowBlock() {
        return weatherBlock().findElement(By.cssSelector(".op_weather4_twoicon_day"));
    }

    public Map<String, String> getTodayWeather() {
        return getwWeather(todayBlock());
    }

    public Map<String, String> getTomorrowWeather() {
        return getwWeather(tomorrowBlock());
    }

    private Map<String, String> getwWeather(WebElement block) {
        String temp = block.findElement(By.cssSelector(".op_weather4_twoicon_temp")).getText();
        String weather = block.findElement(By.cssSelector(".op_weather4_twoicon_weath")).getText();
        Map<String, String> res = new HashMap<String, String>();
        res.put("temp", temp);
        res.put("weather", weather);
        return res;
    }

    public void quit() {
        dr.quit();
    }



}
