package info.itest;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.Map;

import static org.junit.Assert.*;

/**
 * Created by eason on 2017/7/4.
 */
public class BaiduWeatherTest {
    private BaiduWeather weather;

    @Before
    public void initBaiduWeather() {
        weather = new BaiduWeather("深圳");
    }


    @Test
    public void getTodayWeather() throws Exception {
        Map res = weather.getTodayWeather();
        System.out.println(res.toString());
        assertNotNull(res.get("temp"));
        assertNotNull(res.get("weather"));
    }

    @Test
    public void getTomorrowWeather() throws Exception {
        Map res = weather.getTomorrowWeather();
        System.out.println(res.toString());
        assertNotNull(res.get("temp"));
        assertNotNull(res.get("weather"));
    }

    @Test
    public void shouldSearchKeyword() {
        assertTrue(weather.weatherBlock().isDisplayed());
        assertTrue(weather.todayBlock().isDisplayed());
        assertTrue(weather.tomorrowBlock().isDisplayed());
    }

    @After

    public void closeBrowser() {
        weather.quit();
    }

}