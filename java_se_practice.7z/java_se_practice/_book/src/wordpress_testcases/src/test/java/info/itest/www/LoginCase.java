package info.itest.www;

import info.itest.www.pages.DashboardPage;
import info.itest.www.pages.LoginPage;
import org.junit.*;

import static org.junit.Assert.*;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by eason on 2017/7/18.
 */
public class LoginCase {
    static WebDriver dr;
    String domain = "http://139.199.192.100:8000/";
    private LoginPage loginPage;

    @BeforeClass
    public static void startBrowser() {
        dr = new ChromeDriver();
    }

    @AfterClass
    public static void closeBrowser() {
        dr.quit();
    }

    @Before
    public void initLoginPage() {
        dr.get(buildURL("wp-login.php"));
        loginPage = PageFactory.initElements(dr, LoginPage.class);
        loginPage.clear();
    }

    public String buildURL(String path) {
        return domain + path;
    }

    @Test
    public void testLoginSuccess() {
//        Arrange
        String userName = "admin";
        String password = "admin";

        DashboardPage dashboardPage = loginPage.loginSuccess(userName, password, dr);

//        Assert
        assertTrue(dr.getCurrentUrl().contains("wp-admin"));
        WebElement greetingLink = dashboardPage.getGreetingLink();
        assertTrue(greetingLink.getText().contains(userName));
    }

    @Test
    public void testLoginFailedWhenNoUsernameAndPassword() {
        loginPage.login("", "");
//        页面不跳转， 没有错误提示
        assertTrue(dr.getCurrentUrl().contains("wp-login.php"));
    }

    @Test
    public void testLoginFailedWhenCorrectUsernameAndEmptyPassword() {
        String errorMsg = loginPage.loginFailed("admin", "", dr);
        assertTrue(dr.getCurrentUrl().contains("wp-login.php"));
        assertEquals("错误：密码一栏为空。", errorMsg);
    }

    @Test
    public void testLoginFailedWhenCorrectUsernameAndIncorrectPassword() {
        String errorMsg = loginPage.loginFailed("admin", "incorrect", dr);
        assertTrue(dr.getCurrentUrl().contains("wp-login.php"));
        assertEquals("错误：为用户名admin指定的密码不正确。 忘记密码？", errorMsg);
    }

    @Test
    public void testLoginFailedWhenIncorrectUsernameAndIncorrectPassword() {
        String errorMsg = loginPage.loginFailed("incorrect", "incorrect", dr);
        assertTrue(dr.getCurrentUrl().contains("wp-login.php"));
        assertEquals("错误：无效用户名。 忘记密码？", errorMsg);
    }

}
