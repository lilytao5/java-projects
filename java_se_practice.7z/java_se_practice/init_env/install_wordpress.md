# 在本机搭建wordpress环境

### 使用cmder替换默认的命令行工具

windows自带的命令行工具历史悠久而且很不好用，这里建议大家使用[cmder](http://cmder.net/)来替换。

另外cmder里自带了windows的git客户端，这样也省去了大家安装wingit的时间。

[下载地址](http://pan.baidu.com/s/1pL6Y09l)，请使用7zip直接解压即可。

**下面的所有命令行相关操作均请使用cmder完成**


### 安装wamp

建议直接安装[wamp](http://www.wampserver.com/en/)，这是一个php + mysql + apache的全家桶。

[下载地址](https://pan.baidu.com/s/1i5aGHKT)

**安装wamp时如果出现错误，请自行下载更适合自己系统版本的wamp安装**

安装完成后启动wamp服务，只要右下角的托盘变成绿色就是成功了，如果不成功请自行排除问题。

**安装过程中会提示你选择默认的浏览器，这时候选择IE就好了，另外数据库安装过程中如果没有提示你输入密码，那么默认用户名可能是root，密码是空**

### 安装wordpress

[下载地址](http://pan.baidu.com/s/1eS8CGqm)

下载好之后解压到wamp安装目录下的www目录，比如在我的环境下，我解压到了```D:\dev\wamp\www```下面。

访问[http://localhost/wordpress/](http://localhost/wordpress/)，根据提示配置wordpress就好。


### MAC系统

[看这里](https://codex.wordpress.org/Installing_WordPress_Locally_on_Your_Mac_With_MAMP)

注意可能需要科学上网
