# 关于Page Object设计模式

### UI自动化测试面临的问题

* 页面频繁变动
* 用例中需要反复的定位同一个元素
* 每当页面发生变化的时候，需要在大量的用例中寻找变动的部分，工作量大，而且容易遗漏

### Page Obejct模式可以解决这些问题

把页面当成对象，让所有的元素定位都发生在Page对象中，而不是用例中。

每个页面上的元素只定位一次，用例中只需要直接使用页面上已经定位过的元素，隔离了定位的细节，当页面发生变化时，只需要改相应的页面对象，而不需要去改动用例，降低了维护的成本。

### Page Object设计模式的要点

设计页面对象时我们需要注意以下问题

1. public方法用来暴露对外的服务:对于java来说是如此，python的话可以忽略
2. 不要暴露page的内部结构: 不要在除page对象之外的地方做元素定位
3. 一般来说不要在page内做断言: 除非是做页面是否成功加载的断言
4. 返回其他page objects: 当页面发生跳转时，需要返回跳转到页面所代表的po对象
5. 不需要表示整个页面：用到多少元素就定位多少个，不用的就不定位
6. 同一个动作的不同结果用不同方法表示：比如登录有成功和失败之分，这时候最好是定义2个方法

### Page Object类的组成

一般由下面两类方法组成

* 页面上的元素
* 页面上的一些操作的封装，比如封装一个登录方法，加入购物车方法，搜索方法等

### 引用

[官方文档](https://github.com/SeleniumHQ/selenium/wiki/PageObjects)对po模式有详细的描述，请大家仔细阅读体会。

### 重构login测试用例

```java
// LoginPage.java
package info.itest.www.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Created by eason on 2017/8/15.
 */
public class LoginPage {
    private By errorMessageLocator = By.id("login_error");

    @FindBy(how = How.ID, using = "user_login")
    private WebElement username;

    @FindBy(id = "user_pass")
    private WebElement password;

    @FindBy(id = "wp-submit")
    private WebElement loginBtn;

    public DashboardPage loginSuccess(String uName, String passwd, WebDriver dr) {
        login(uName, passwd);
        return PageFactory.initElements(dr, DashboardPage.class);
    }

    public void login(String uName, String passwd) {
        username.sendKeys(uName);
        password.sendKeys(passwd);
        loginBtn.click();
    }

    public String loginFailed(String uName, String passwd, WebDriver dr) {
        login(uName, passwd);
        WebDriverWait wait = new WebDriverWait(dr, 5);
        wait.until(ExpectedConditions.visibilityOfElementLocated(errorMessageLocator));
        return dr.findElement(errorMessageLocator).getText().trim();
    }

    public void clear() {
        username.clear();
        password.clear();
    }
}
```

```java
// DashboardPage.java
package info.itest.www.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Created by eason on 2017/8/15.
 */
public class DashboardPage {

    @FindBy(css = "#wp-admin-bar-my-account .ab-item")
    private WebElement greetingLink;

    public WebElement getGreetingLink() {
        return greetingLink;
    }
}
```

```java
// LoginCase.java
package info.itest.www;

import info.itest.www.pages.DashboardPage;
import info.itest.www.pages.LoginPage;
import org.junit.*;

import static org.junit.Assert.*;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by eason on 2017/7/18.
 */
public class LoginCase {
    static WebDriver dr;
    String domain = "http://139.199.192.100:8000/";
    private LoginPage loginPage;

    @BeforeClass
    public static void startBrowser() {
        dr = new ChromeDriver();
    }

    @AfterClass
    public static void closeBrowser() {
        dr.quit();
    }

    @Before
    public void initLoginPage() {
        dr.get(buildURL("wp-login.php"));
        loginPage = PageFactory.initElements(dr, LoginPage.class);
        loginPage.clear();
    }

    public String buildURL(String path) {
        return domain + path;
    }

    @Test
    public void testLoginSuccess() {
//        Arrange
        String userName = "admin";
        String password = "admin";

        DashboardPage dashboardPage = loginPage.loginSuccess(userName, password, dr);

//        Assert
        assertTrue(dr.getCurrentUrl().contains("wp-admin"));
        WebElement greetingLink = dashboardPage.getGreetingLink();
        assertTrue(greetingLink.getText().contains(userName));
    }

    @Test
    public void testLoginFailedWhenNoUsernameAndPassword() {
        loginPage.login("", "");
//        页面不跳转， 没有错误提示
        assertTrue(dr.getCurrentUrl().contains("wp-login.php"));
    }

    @Test
    public void testLoginFailedWhenCorrectUsernameAndEmptyPassword() {
        String errorMsg = loginPage.loginFailed("admin", "", dr);
        assertTrue(dr.getCurrentUrl().contains("wp-login.php"));
        assertEquals("错误：密码一栏为空。", errorMsg);
    }

    @Test
    public void testLoginFailedWhenCorrectUsernameAndIncorrectPassword() {
        String errorMsg = loginPage.loginFailed("admin", "incorrect", dr);
        assertTrue(dr.getCurrentUrl().contains("wp-login.php"));
        assertEquals("错误：为用户名admin指定的密码不正确。 忘记密码？", errorMsg);
    }

    @Test
    public void testLoginFailedWhenIncorrectUsernameAndIncorrectPassword() {
        String errorMsg = loginPage.loginFailed("incorrect", "incorrect", dr);
        assertTrue(dr.getCurrentUrl().contains("wp-login.php"));
        assertEquals("错误：无效用户名。 忘记密码？", errorMsg);
    }

}
```
