# 实战: Guess Number

### 学习目标

* while
* if
* [生成随机数](www.javapractices.com/topic/TopicAction.do?Id=62)
* [获取用户输入](https://stackoverflow.com/questions/5287538/how-can-i-get-the-user-input-in-java)


### 需求

* 用户输入姓名后生成1个100之内的随机数
* 如果用户猜的数字比目标数字大，提示过大
* 如果用户猜的数字比目标数字小，提示过小
* 如果用户猜测正确,打印目标数字，退出游戏

```
I am thinking of a number between 1 and 100.
Take a guess.
99
Your guess is too high.
Take a guess.
19
Your guess is too low.
Take a guess.
4
Good job, the correct number is 4.
```

注意测试下面的情况

* 如果用户输入的不是数字，期望程序可以正确退出，也就是不报错


### 新需求

* 用户输入q或者Q时可以退出程序

### 参考实现

```java
package info.itest;

import java.util.Random;
import java.util.Scanner;


public class Main {

    public static final int MAX = 100;
    public static final String QUIT = "q";

    public static void main(String[] args) {
        System.out.println("I am thinking of a number between 1 and 100.");

        Random rand = new Random();
        int target = rand.nextInt(MAX);

        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Take a guess.");
            String userInput = scanner.next();

            if (userInput.toLowerCase().contentEquals(QUIT)) {
                System.out.println("Goodbye");
                break;
            }

            int userGuessNumber;
            try {
                userGuessNumber = Integer.parseInt(userInput);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number");
                break;
            }

            if (userGuessNumber > target) {
                System.out.println("Your guess is too high");
            } else if (userGuessNumber < target) {
                System.out.println("Your guess is too low");
            } else {
                System.out.println("Good job! The correct number is " + target);
                break;
            }

        }

    }
}
```
