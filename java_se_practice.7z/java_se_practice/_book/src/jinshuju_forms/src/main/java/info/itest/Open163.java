package info.itest;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

/**
 * Created by eason on 2017/7/11.
 */
public class Open163 {
    private WebDriver dr;
    private WebDriverWait wait;
    private By frameLoctor = By.cssSelector("iframe[src*=webzj]");

    public Open163() {
        dr = new ChromeDriver();
        dr.get("https://open.163.com/");
    }

    public void login(String username, String password) throws InterruptedException {
        dr.findElement(By.id("urs_login_btn")).click();
        Thread.sleep(3000);
        switchToLoginFrame();

        dr.findElement(By.name("email")).sendKeys(username);
        dr.findElement(By.name("password")).sendKeys(password);
        dr.findElement(By.id("dologin")).click();
    }

    public void switchToLoginFrame() {
        List<WebElement> frames = dr.findElements(By.tagName("iframe"));
        for(WebElement i : frames) {
            System.out.println(i.getAttribute("id"));
            if(i.getAttribute("id").contains("x-URS-iframe")) {
                dr.switchTo().frame(i);
                return;
            }
        }
        System.out.println("Can not find login frame");
    }

    public String loginFailed(String username, String password) throws InterruptedException {
        login(username, password);
        WebDriverWait wait = new WebDriverWait(dr, 5);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("ferrorhead")));
        return dr.findElement(By.className("ferrorhead")).getText();
    }

    void quit() {
        dr.quit();
    }
}
