# 自学内容--面向对象的编程

* [什么是对象?](http://docs.oracle.com/javase/tutorial/java/concepts/object.html)
* [什么是类?](http://docs.oracle.com/javase/tutorial/java/concepts/class.html)
* [什么是继承?](http://docs.oracle.com/javase/tutorial/java/concepts/inheritance.html)
* [什么是接口?](http://docs.oracle.com/javase/tutorial/java/concepts/interface.html)
* [什么是包?](http://docs.oracle.com/javase/tutorial/java/concepts/package.html)

### 代码精读

下面的代码请先抄一遍并且可以正确运行后再精读

关于类

```java
class Bicycle {

    int cadence = 0;
    int speed = 0;
    int gear = 1;

    void changeCadence(int newValue) {
         cadence = newValue;
    }

    void changeGear(int newValue) {
         gear = newValue;
    }

    void speedUp(int increment) {
         speed = speed + increment;   
    }

    void applyBrakes(int decrement) {
         speed = speed - decrement;
    }

    void printStates() {
         System.out.println("cadence:" +
             cadence + " speed:" +
             speed + " gear:" + gear);
    }
}


class BicycleDemo {
    public static void main(String[] args) {

        // Create two different
        // Bicycle objects
        Bicycle bike1 = new Bicycle();
        Bicycle bike2 = new Bicycle();

        // Invoke methods on
        // those objects
        bike1.changeCadence(50);
        bike1.speedUp(10);
        bike1.changeGear(2);
        bike1.printStates();

        bike2.changeCadence(50);
        bike2.speedUp(10);
        bike2.changeGear(2);
        bike2.changeCadence(40);
        bike2.speedUp(10);
        bike2.changeGear(3);
        bike2.printStates();
    }
}

```

关于接口

```java
interface Bicycle {

    //  wheel revolutions per minute
    void changeCadence(int newValue);

    void changeGear(int newValue);

    void speedUp(int increment);

    void applyBrakes(int decrement);
}

class ACMEBicycle implements Bicycle {

    int cadence = 0;
    int speed = 0;
    int gear = 1;

   // The compiler will now require that methods
   // changeCadence, changeGear, speedUp, and applyBrakes
   // all be implemented. Compilation will fail if those
   // methods are missing from this class.

    void changeCadence(int newValue) {
         cadence = newValue;
    }

    void changeGear(int newValue) {
         gear = newValue;
    }

    void speedUp(int increment) {
         speed = speed + increment;   
    }

    void applyBrakes(int decrement) {
         speed = speed - decrement;
    }

    void printStates() {
         System.out.println("cadence:" +
             cadence + " speed:" +
             speed + " gear:" + gear);
    }
}
```

### 思考题

* Real-world objects contain () and ().
* A software object's state is stored in ().
* A software object's behavior is exposed through ().
* Hiding internal data from the outside world, and accessing it only through publicly exposed methods is known as data ().
* A blueprint for a software object is called a ().
* Common behavior can be defined in a () and inherited into a () using the () keyword.
* A collection of methods with no implementation is called an ().
* A namespace that organizes classes and interfaces by functionality is called a ().
* The term API stands for ()?

### 练习

* 定义一个Person类，每个人有名字name，年龄age, 和性别sex。定义一些方法可以获取和设置名字，年龄和性别；
* 定义一个Man类，继承自Person类，Man类的性别默认是male;
* 定义一个Woman类，继承自Person类，Man类的性别默认是female;
* 创建一些Man和Woman的对象，设置并打印各个对象的名字年龄及性别；
