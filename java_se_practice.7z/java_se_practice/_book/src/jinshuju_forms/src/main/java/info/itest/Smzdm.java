package info.itest;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

/**
 * Created by eason on 2017/7/11.
 */
public class Smzdm {
    private WebDriver dr;
    private WebDriverWait wait;
    private By loginLink = By.className("J_login_trigger");

    public Smzdm() {
        dr = new ChromeDriver();
        dr.get("http://www.smzdm.com/");
        wait = new WebDriverWait(dr, 5);
    }

    public void login(String username, String password) throws InterruptedException {
        Thread.sleep(2000);
        dr.findElement(By.id("skip-step")).click();

        wait.until(ExpectedConditions.visibilityOfElementLocated(loginLink));
        dr.findElement(loginLink).click();
        Thread.sleep(3000);
        switchToLoginFrame();

        dr.findElement(By.name("username")).sendKeys(username);
        dr.findElement(By.name("password")).sendKeys(password);
        dr.findElement(By.id("login_submit")).click();
    }

    public void switchToLoginFrame() {
        List<WebElement> frames = dr.findElements(By.tagName("iframe"));
        for(WebElement i : frames) {
            System.out.println(i.getAttribute("id"));
            if(i.getAttribute("id").contains("J_login_iframe")) {
                dr.switchTo().frame(i);
                return;
            }
        }
        System.out.println("Can not find login frame");
    }

    public WebElement userLink() throws InterruptedException {
        Thread.sleep(3000);
        return dr.findElement(By.cssSelector(".J_nav_username"));
    }

    public void signUp() throws InterruptedException {
        signUpLink().click();
    }

    public WebElement signUpLink() throws InterruptedException {
        Thread.sleep(2000);
        return dr.findElement(By.className("J_punch"));
    }


    void quit() {
        dr.quit();
    }
}
