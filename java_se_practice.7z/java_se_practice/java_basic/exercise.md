# 基础练习

1, 在屏幕上打印'hello'，另起一行打印出你的名字

预期

```
Hello
Ethan Han
```
----------

2, 打印2个数的和

测试数据：74 + 36

预期：110

----------

3, 打印2个数的商

测试数据：50 / 3

预期：16

----------

4, 打印下列操作的结果

测试数据：50 / 3

```
a. -5 + 8 * 6
b. (55+9) % 9
c. 20 + -3*5 / 8
d. 5 + 15 / 3 * 2 - 8 % 3
```

预期:

```
43
1
19
13
```
----------

5, 用户输入2个数，然后打印出这两个数的乘积

需求：

```
Input first number: 25
Input second number: 5
```

预期：25 x 5 = 125

----------

6, 用户输入2个数，分别打印出这两个数的和差积商和余数

需求:

```
Input first number: 125
Input second number: 24
```

预期:

```
125 + 24 = 149
125 - 24 = 101
125 x 24 = 3000
125 / 24 = 5
125 mod 24 = 5
```
----------

7, 用户输入1个数，打印出这个数的乘法表，最多乘到10

测试数据: 8

预期:

```
8 x 1 = 8
8 x 2 = 16
8 x 3 = 24
...
8 x 10 = 80
```
----------

8, 打印下面的图形

需求：

```
   J    a   v     v  a                                                  
   J   a a   v   v  a a                                                 
J  J  aaaaa   V V  aaaaa                                                
 JJ  a     a   V  a     a
```
-----------

9, 计算下面表达式的值

((25.5 * 3.5 - 3.5 * 3.5) / (40.5 - 4.5))

预期：2.138888888888889

-----------

10, 计算下面公式的值

4.0 * (1 - (1.0/3) + (1.0/5) - (1.0/7) + (1.0/9) - (1.0/11))

预期：2.9760461760461765

-----------

11, 计算圆的面积(area)和周长(perimeter)

Radius = 7.5(半径)

预期：

Perimeter is = 47.12388980384689

Area is = 176.71458676442586

-----------

12, 用户输入3个数字，求平均值

-----------

13, 打印矩形的面积和周长

Width = 5.5 Height = 8.5

预期：

Area is 5.6 * 8.5 = 47.60

Perimeter is 2 * (5.6 + 8.5) = 47.60

-----------

14, 打印美国国旗

需求

```
* * * * * * ==================================                          
 * * * * *  ==================================                          
* * * * * * ==================================                          
 * * * * *  ==================================                          
* * * * * * ==================================                          
 * * * * *  ==================================                          
* * * * * * ==================================                          
 * * * * *  ==================================                          
* * * * * * ==================================                          
==============================================                          
==============================================                          
==============================================                          
==============================================                          
==============================================                          
==============================================
```

-----------

15, 交换2个变量的值

-----------

16, 打印笑脸

```
 +"""""+                                                 
[| o o |]                                                
 |  ^  |                                                 
 | '-' |                                                 
 +-----+
```
-----------

17, 用户输入2个二进制数，对这两个二进制数做加法

需求:

Input first binary number: 10

Input second binary number: 11

预期：

Sum of two binary numbers: 101

-----------

18, 用户输入2个二进制数，对这两个二进制数做乘法

需求:

Input first binary number: 10

Input second binary number: 11

预期:

Product of two binary numbers: 110

-----------

19, 将十进制数转换成二进制

需求:

Input a Decimal Number : 5

预期：

Binary number is: 101

-----------

20, 将十进制数转成十六进制

需求:

Input a decimal number: 15

预期:

Hexadecimal number is : F

-----------

21, 将十进制数转乘八进制

需求:

Input a Decimal Number: 15

预期：

Octal number is: 17  

-------------

22, 二进制转十进制

需求：

Input a binary number: 100

预期：

Decimal Number: 4

--------------

23, 二进制转十六进制

需求：

Input a Binary Number: 1101

预期：

HexaDecimal value: D

------------------

24, 二进制转八进制

需求：

Input a Binary Number: 111

预期：

Octal number: 7

------------------

25, 八进制转十进制

需求：

Input any octal number: 10

预期：

Equivalent decimal number: 8


-------------

26, 八进制转二进制

需求：

Input any octal number: 7

预期：

Equivalent binary number: 111

----------

27, 八进制转十六进制

需求：

Input a octal number : 100

预期：

Equivalent hexadecimal number: 40

------------

28, 十六进制转十进制

需求：

Input a hexadecimal number: 25

预期：

Equivalent decimal number is: 37

-----------

29, 十六进制转二进制

需求：

Enter Hexadecimal Number : 37

预期：

Equivalent Binary Number is: 110111

-----------

30, 十六进制转八进制

需求：

Input a hexadecimal number: 40

预期：

Equivalent of octal number is: 100

-----------

31, 写个java程序检查java的安装信息

预期：

```
Java Version: 1.8.0_71                                                            
Java Runtime Version: 1.8.0_71-b15                                                
Java Home: /opt/jdk/jdk1.8.0_71/jre                                               
Java Vendor: Oracle Corporation                                                   
Java Vendor URL: http://java.oracle.com/                                          
Java Class Path: .
```

--------------

32, 比较2个数字

需求：

Input Data:

Input first integer: 25

Input second integer: 39

预期：

```
25 != 39                                                                          
25 < 39                                                                           
25 <= 39
```

------------

33, 输入一个数字，计算该数字各位的和

需求：

Input an integer: 25

预期：

The sum of the digits is: 7

------------

34, 反转字符串

需求：

Input a string: The quick brown fox

预期：

Reverse string: xof nworb kciuq ehT

-------------

35, 输入一串字符，统计出空格，字母，数字和其他字符的数量

预期：

```
letter: 23                                               
space: 9                                                 
number: 10                                               
other: 6
```

--------------

36, 从1 2 3 4 里选出3个数字组成不重复3位数，并打印出一共有多少种组合方式

预期：

```
123                                                      
124                                                      
...                                            

431                                                      
432                                                      
Total number of the three-digit-number is 24
```
