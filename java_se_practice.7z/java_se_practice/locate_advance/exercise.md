# 练习：登录什么值得买并签到得积分

[什么值得买](http://www.smzdm.com/)
