package info.itest;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by eason on 2017/7/11.
 */
public class Open163Test {
    private Open163 site;

    @Before
    public void setUp() throws Exception {
        site = new Open163();
    }

    @After
    public void tearDown() throws Exception {
        site.quit();
    }

    @Test
    public void loginFailed() throws Exception {
        String username = String.format("%s@test.com", System.currentTimeMillis());
        String errMsg = site.loginFailed(username, "password");
        System.out.println(errMsg);
        assertEquals("帐号或密码错误", errMsg);
    }

}