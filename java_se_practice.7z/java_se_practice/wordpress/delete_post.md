#删除文章

### 批量创建

使用fastjson库

```xml
<dependency>
     <groupId>com.alibaba</groupId>
     <artifactId>fastjson</artifactId>
     <version>1.2.21</version>
</dependency>
```

```java
// PostEntiry.java
public class PostEntity {
    private String title;
    private String content;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}

// CreatePostCase.java
public class CreatePostCase {
    WebDriver dr;
    String domain = "http://139.199.192.100:8000/";
    String json = "[{\"title\":\"post1\",\"content\":\"post1\"},{\"title\":\"post2\",\"content\":\"post2\"}]";


    @Before
    public void startBrowser() {
        dr = new ChromeDriver();

        login("admin", "admin");
    }

    @After
    public void closeBrowser() {
        dr.quit();
    }

    public String buildURL(String path) {
        return domain + path;
    }

    public void login(String username, String password) {
        String loginURL = buildURL("wp-login.php");
        dr.get(loginURL);
        byId("user_login").sendKeys(username);
        byId("user_pass").sendKeys(password);
        byId("wp-submit").click();
    }

    @Test
    public void testCreatePostSuccess() {
        dr.get(buildURL("wp-admin/post-new.php"));
        String title = String.format("Test title %s", UUID.randomUUID());
        byName("post_title").sendKeys(title);
        setContent("this is content");
        byName("publish").click();

        dr.get(buildURL("wp-admin/edit.php"));
        WebElement latestPost = byCss(".row-title");

        assertEquals(title, latestPost.getText());
    }

    @Test
    public void batchCreatePostFromJson() {
        List<PostEntity> posts = JSON.parseArray(json, PostEntity.class);
        for (PostEntity post : posts) {
            createPost(post.getTitle(), post.getContent());
        }
    }

    public void createPost(String title, String content) {

        dr.get(buildURL("wp-admin/post-new.php"));
        byName("post_title").sendKeys(title);
        setContent(content);
        byName("publish").click();
    }

    private void setContent(String content) {
        String js = String.format("document.getElementById('content_ifr').contentWindow.document.body.innerHTML = '%s'",
                                    content);

        ((JavascriptExecutor)dr).executeScript(js);
    }

    WebElement byId(String id) {
        return dr.findElement(By.id(id));
    }

    WebElement byName(String name) {
        return dr.findElement(By.name(name));
    }

    WebElement byCss(String css) {
        return dr.findElement(By.cssSelector(css));
    }
}
```

### 鼠标事件

ActionChains 类提供了鼠标操作的常用方法：

* perform()： 执行所有 ActionChains 中存储的行为；
* context_click()： 右击；
* double_click()： 双击；
* drag_and_drop()： 拖动；
* move_to_element()： 鼠标悬停。

```java

from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains

driver = webdriver.Chrome()
driver.get("https://www.baidu.cn")

above = driver.find_element_by_link_text("设置")
ActionChains(driver).move_to_element(above).perform()

```

### 代码

```java
public class DeletePostCase {
    WebDriver dr;
    String domain = "http://139.199.192.100:8000/";


    @Before
    public void startBrowser() {
        dr = new ChromeDriver();

        login("admin", "admin");
    }

    @After
    public void closeBrowser() {
        dr.quit();
    }

    public String buildURL(String path) {
        return domain + path;
    }

    public void login(String username, String password) {
        String loginURL = buildURL("wp-login.php");
        dr.get(loginURL);
        byId("user_login").sendKeys(username);
        byId("user_pass").sendKeys(password);
        byId("wp-submit").click();
    }

    @Test
    public void deletePostSuccess() {
        String title = String.format("Test title %s", UUID.randomUUID());
        String postID = createPostAndReturnID(title, "this is content");
        String rowID = "post-" + postID;
        dr.get(buildURL("wp-admin/edit.php"));
        WebElement row = byId(rowID);
        Actions actions = new Actions(dr);
        actions.moveToElement(row).perform();

        row.findElement(By.className("trash")).click();

        try {
            byId(rowID);
            fail("删除失败");
        } catch (NoSuchElementException e) {
            assertTrue(true);
        }
    }

    public void createPost(String title, String content) {

        dr.get(buildURL("wp-admin/post-new.php"));
        byName("post_title").sendKeys(title);
        setContent(content);
        byName("publish").click();
    }

    public String createPostAndReturnID(String title, String content) {
        createPost(title, content);
        String linkText = byId("sample-permalink").getText();
        return linkText.split("=")[1];
    }

    private void setContent(String content) {
        String js = String.format("document.getElementById('content_ifr').contentWindow.document.body.innerHTML = '%s'",
                content);

        ((JavascriptExecutor)dr).executeScript(js);
    }

    WebElement byId(String id) {
        return dr.findElement(By.id(id));
    }

    WebElement byName(String name) {
        return dr.findElement(By.name(name));
    }

    WebElement byCss(String css) {
        return dr.findElement(By.cssSelector(css));
    }
}
```


### 作业

预习page object设计模式
