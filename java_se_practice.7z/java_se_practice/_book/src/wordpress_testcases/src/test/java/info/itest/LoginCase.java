package info.itest;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 * Created by eason on 2017/7/18.
 */
public class LoginCase{
    private String domain = "http://139.199.192.100:8000/";
    private WebDriver dr;

    @Before
    public void startBrowser() {
        dr = new ChromeDriver();
    }

    public String buildURL(String path) {
        return domain + path;
    }

    @After
    public void closeBrowser() {
        dr.quit();
    }

    @Test
    public void loginSuccess() {
        String userName = "admin";
        String password = "admin";

        dr.get(buildURL("wp-login.php"));
        byId("user_login").sendKeys(userName);
        byId("user_pass").sendKeys(password);
        byId("wp-submit").click();

        assertTrue(dr.getCurrentUrl().contains("wp-admin"));

        WebElement greetLink = byCss("#wp-admin-bar-my-account .ab-item");
        assertTrue(greetLink.getText().contains(userName));
    }

    public WebElement byId(String id) {
        return dr.findElement(By.id(id));
    }

    public WebElement byName(String name) {
        return dr.findElement(By.name(name));
    }

    public WebElement byCss(String css) {
        return dr.findElement(By.cssSelector(css));
    }
}
