package info.itest.www;

import info.itest.www.pages.EditPostPage;
import info.itest.www.pages.LoginPage;
import info.itest.www.pages.PostListPage;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import java.util.UUID;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

/**
 * Created by eason on 2017/8/1.
 */
public class DeletePostCase {
    WebDriver dr;
    String domain = "http://139.199.192.100:8000/";
    LoginPage loginPage;


    @Before
    public void startBrowser() {
        dr = new ChromeDriver();

        dr.get(buildURL("wp-login.php"));
        loginPage = PageFactory.initElements(dr, LoginPage.class);
        loginPage.loginSuccess("admin", "admin", dr);
    }

    @After
    public void closeBrowser() {
        dr.quit();
    }

    public String buildURL(String path) {
        return domain + path;
    }

    @Test
    public void deletePostSuccess() {
        String title = String.format("Test title %s", UUID.randomUUID());
        dr.get(buildURL("wp-admin/post-new.php"));
        EditPostPage editPostPage = PageFactory.initElements(dr, EditPostPage.class);
        String postID = editPostPage.createPostReturnID(title, "content", dr);

        dr.get(buildURL("wp-admin/edit.php"));
        PostListPage postListPage = PageFactory.initElements(dr, PostListPage.class);
        postListPage.deletePost(postID, dr);

        try {
            postListPage.getRow(postID, dr);
            fail("删除失败");
        } catch (NoSuchElementException e) {
            assertTrue(true);
        }
    }

}
