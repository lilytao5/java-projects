# 简介

java selenium自动化测试实战教程

本教程中会出现一些英文的文档和参考材料，请不要有抗拒和恐惧的心理，通过字典或各种翻译工具进行查看。

### 如何查看本教材

这本书是用gitbook写的，所有的内容最后会被转换成html页面，因为只需要在本机启动简单的http服务就可以进行查看了。

### tomcat篇

使用java的同学可以先安装tomcat，并启动tomcat查看。

安装教程在[这里](http://cn.bing.com/search?q=install+tomcat&qs=AS&pq=install+tom&sc=8-11&cvid=2B4A7934B510434B87B7574B9CC2E45B&FORM=QBLH&sp=1)

* 将_book文件夹拷贝到tomcat安装路径下的webapps目录

* 在命令行中进入tomcat安装目录下的bin目录，执行```startup.bat```

* 浏览器中访问[http://localhost:8080/_book/](http://localhost:8080/_book/)

### python篇(推荐方式)

如果你本机安装了python，那么在命令行中cd到_book目录，运行

```
# python2
python -m SimpleHTTPServer

# python3
python -m http.server
```

然后在浏览器中打开[http://localhost:8000/](http://localhost:8000/)

### nodejs篇

```
npm install -g http-server  
cd _book
http-server
```

然后在浏览器中打开[http://localhost:8080/](http://localhost:8080/)
