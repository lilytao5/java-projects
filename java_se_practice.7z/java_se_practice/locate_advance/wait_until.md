# 实战：登录网易公开课

[网易公开课](https://open.163.com/)


### 代码

#### Open163.java

```java

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

/**
 * Created by eason on 2017/7/11.
 */
public class Open163 {
    private WebDriver dr;
    private WebDriverWait wait;
    private By frameLoctor = By.cssSelector("iframe[src*=webzj]");

    public Open163() {
        dr = new ChromeDriver();
        dr.get("https://open.163.com/");
    }

    public void login(String username, String password) throws InterruptedException {
        dr.findElement(By.id("urs_login_btn")).click();
        Thread.sleep(3000);
        switchToLoginFrame();

        dr.findElement(By.name("email")).sendKeys(username);
        dr.findElement(By.name("password")).sendKeys(password);
        dr.findElement(By.id("dologin")).click();
    }

    public void switchToLoginFrame() {
        List<WebElement> frames = dr.findElements(By.tagName("iframe"));
        for(WebElement i : frames) {
            System.out.println(i.getAttribute("id"));
            if(i.getAttribute("id").contains("x-URS-iframe")) {
                dr.switchTo().frame(i);
                return;
            }
        }
        System.out.println("Can not find login frame");
    }

    public String loginFailed(String username, String password) throws InterruptedException {
        login(username, password);
        WebDriverWait wait = new WebDriverWait(dr, 5);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("ferrorhead")));
        return dr.findElement(By.className("ferrorhead")).getText();
    }

    void quit() {
        dr.quit();
    }
}
```

#### Open163Test.java

```java
package info.itest;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by eason on 2017/7/11.
 */
public class Open163Test {
    private Open163 site;

    @Before
    public void setUp() throws Exception {
        site = new Open163();
    }

    @After
    public void tearDown() throws Exception {
        site.quit();
    }

    @Test
    public void loginFailed() throws Exception {
        String username = String.format("%s@test.com", System.currentTimeMillis());
        String errMsg = site.loginFailed(username, "password");
        System.out.println(errMsg);
        assertEquals("帐号或密码错误", errMsg);
    }

}
```
