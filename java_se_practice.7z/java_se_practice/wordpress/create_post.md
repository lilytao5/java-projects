# 创建文章

### 登录失败的用例

```java
public class LoginCase {
    static WebDriver dr;
    String domain = "http://139.199.192.100:8000/";
    private By errorMessageLocator = By.id("login_error");

    @BeforeClass
    public static void startBrowser() {
        dr = new ChromeDriver();
    }

    @AfterClass
    public static void closeBrowser() {
        dr.quit();
    }

    public String buildURL(String path) {
        return domain + path;
    }

    @Test
    public void testLoginSuccess() {
//        Arrange
        String userName = "admin";
        String password = "admin";

//        Act
        login(userName, password);

//        Assert
        assertTrue(dr.getCurrentUrl().contains("wp-admin"));
        WebElement greetingLink = byCss("#wp-admin-bar-my-account .ab-item");
        assertTrue(greetingLink.getText().contains(userName));
    }

    @Test
    public void testLoginFailedWhenNoUsernameAndPassword() {
        login("", "");
//        页面不跳转， 没有错误提示
        assertTrue(dr.getCurrentUrl().contains("wp-login.php"));
    }

    @Test
    public void testLoginFailedWhenCorrectUsernameAndEmptyPassword() {
        String errorMsg = loginFailed("admin", "");
        assertTrue(dr.getCurrentUrl().contains("wp-login.php"));
        assertEquals("错误：密码一栏为空。", errorMsg);
    }

    @Test
    public void testLoginFailedWhenCorrectUsernameAndIncorrectPassword() {
        String errorMsg = loginFailed("admin", "incorrect");
        assertTrue(dr.getCurrentUrl().contains("wp-login.php"));
        assertEquals("错误：为用户名admin指定的密码不正确。 忘记密码？", errorMsg);
    }

    @Test
    public void testLoginFailedWhenIncorrectUsernameAndIncorrectPassword() {
        String errorMsg = loginFailed("incorrect", "incorrect");
        assertTrue(dr.getCurrentUrl().contains("wp-login.php"));
        assertEquals("错误：无效用户名。 忘记密码？", errorMsg);
    }

    public String loginFailed(String userName, String password) {
        login(userName, password);
        WebDriverWait wait = new WebDriverWait(dr, 5);
        wait.until(ExpectedConditions.visibilityOfElementLocated(errorMessageLocator));
        return by(errorMessageLocator).getText().trim();
    }

    public void login(String userName, String password) {
        dr.get(buildURL("wp-login.php"));
        byId("user_login").clear();
        byId("user_login").sendKeys(userName);
        byId("user_pass").clear();
        byId("user_pass").sendKeys(password);
        byId("wp-submit").click();
    }

    WebElement byId(String id) {
        return dr.findElement(By.id(id));
    }

    WebElement by(By locator) {
        return dr.findElement(locator);
    }

    WebElement byName(String name) {
        return dr.findElement(By.name(name));
    }

    WebElement byCss(String css) {
        return dr.findElement(By.cssSelector(css));
    }
}
```


### 富文本框

网页中嵌入的word

一般可以使用js进行设置

```javascript
document.getElementById('content_ifr').contentWindow.document.body.innerHTML = '赋值'
```


### 表单定位原则

* 尽量用name去定位
* 实在定位不到元素可以看看是不是页面上有frame


### 代码

```java
public class CreatePostCase {
    WebDriver dr;
    String domain = "http://139.199.192.100:8000/";

    @Before
    public void startBrowser() {
        dr = new ChromeDriver();

        login("admin", "admin");
    }

    @After
    public void closeBrowser() {
        dr.quit();
    }

    public String buildURL(String path) {
        return domain + path;
    }

    public void login(String username, String password) {
        String loginURL = buildURL("wp-login.php");
        dr.get(loginURL);
        byId("user_login").sendKeys(username);
        byId("user_pass").sendKeys(password);
        byId("wp-submit").click();
    }

    @Test
    public void testCreatePostSuccess() {
        dr.get(buildURL("wp-admin/post-new.php"));
        String title = String.format("Test title %s", UUID.randomUUID());
        byName("post_title").sendKeys(title);
        setContent("this is content");
        byName("publish").click();

        dr.get(buildURL("wp-admin/edit.php"));
        WebElement latestPost = byCss(".row-title");

        assertEquals(title, latestPost.getText());
    }

    private void setContent(String content) {
        String js = String.format("document.getElementById('content_ifr').contentWindow.document.body.innerHTML = '%s'",
                                    content);

        ((JavascriptExecutor)dr).executeScript(js);
    }

    WebElement byId(String id) {
        return dr.findElement(By.id(id));
    }

    WebElement byName(String name) {
        return dr.findElement(By.name(name));
    }

    WebElement byCss(String css) {
        return dr.findElement(By.cssSelector(css));
    }
}
```

### 作业

读取json文件批量创建文章

```
"[{"title":"post1","content":"post1"},{"title":"post2","content":"post2"}]"
```
