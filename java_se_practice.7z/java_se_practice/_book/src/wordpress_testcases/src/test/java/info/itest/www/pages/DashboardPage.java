package info.itest.www.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Created by eason on 2017/8/15.
 */
public class DashboardPage {

    @FindBy(css = "#wp-admin-bar-my-account .ab-item")
    private WebElement greetingLink;

    public WebElement getGreetingLink() {
        return greetingLink;
    }
}
