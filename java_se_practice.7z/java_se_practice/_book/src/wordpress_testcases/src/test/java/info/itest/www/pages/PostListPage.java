package info.itest.www.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

/**
 * Created by eason on 2017/8/15.
 */
public class PostListPage {

    @FindBy(css = ".row-title")
    private WebElement firstPost;

    public WebElement getFirstPost() {
        return firstPost;
    }

    public void deletePost(String postID, WebDriver dr) {
        WebElement row = getRow(postID, dr);
        Actions actions = new Actions(dr);
        actions.moveToElement(row).perform();
        row.findElement(By.className("trash")).click();
    }

    public WebElement getRow(String postID, WebDriver dr) {
        String rowID = "post-" + postID;
        return dr.findElement(By.id(rowID));
    }
}
