# 登录用例

### 测试金字塔

![](http://wx1.sinaimg.cn/mw690/726a2979gy1fho5jfxn6zj20dm09q74j.jpg)

* 越往上越接近真实用户
* 越往上实现难度越大
* 越往上对系统集成的程度越高
* 越往上实现成本越高
* 越往上用例数量应该越少

### 设计

3A原则，略

### 断言

我们怎么判断登录成功呢？

* 页面跳转(失败的话页面没有跳转)
* 用户能感知到的信息(比如右上角的欢迎信息)

### 代码

```java
package info.itest;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 * Created by eason on 2017/7/18.
 */
public class LoginCase{
    private String domain = "http://139.199.192.100:8000/";
    private WebDriver dr;

    @Before
    public void startBrowser() {
        dr = new ChromeDriver();
    }

    public String buildURL(String path) {
        return domain + path;
    }

    @After
    public void closeBrowser() {
        dr.quit();
    }

    @Test
    public void loginSuccess() {
        String userName = "admin";
        String password = "admin";

        dr.get(buildURL("wp-login.php"));
        byId("user_login").sendKeys(userName);
        byId("user_pass").sendKeys(password);
        byId("wp-submit").click();

        assertTrue(dr.getCurrentUrl().contains("wp-admin"));

        WebElement greetLink = byCss("#wp-admin-bar-my-account .ab-item");
        assertTrue(greetLink.getText().contains(userName));
    }

    public WebElement byId(String id) {
        return dr.findElement(By.id(id));
    }

    public WebElement byName(String name) {
        return dr.findElement(By.name(name));
    }

    public WebElement byCss(String css) {
        return dr.findElement(By.cssSelector(css));
    }
}
```

### 作业

测试登录失败的情况

分下面一些场景

|场景|系统提示|
|-------------|
|用户名密码为空|无提示信息|
|正确的用户名, 密码不填| 错误：密码一栏为空。|
|正确的用户名, 密码乱填| 错误：为用户名admin指定的密码不正确。 忘记密码？|
|不正确的用户名, 密码乱填| 错误：无效用户名。 忘记密码？|
