package info.itest.www;

import info.itest.www.pages.EditPostPage;
import info.itest.www.pages.LoginPage;
import info.itest.www.pages.PostListPage;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import java.util.UUID;

import static org.junit.Assert.assertEquals;

/**
 * Created by eason on 2017/7/23.
 */

public class TestCreatePostCase {
    WebDriver dr;
    String domain = "http://139.199.192.100:8000/";
    LoginPage loginPage;


    @Before
    public void startBrowser() {
        dr = new ChromeDriver();

        dr.get(buildURL("wp-login.php"));
        loginPage = PageFactory.initElements(dr, LoginPage.class);
        loginPage.loginSuccess("admin", "admin", dr);
    }

    @After
    public void closeBrowser() {
        dr.quit();
    }

    public String buildURL(String path) {
        return domain + path;
    }

    @Test
    public void testCreatePostSuccess() {
        dr.get(buildURL("wp-admin/post-new.php"));
        EditPostPage editPostPage = PageFactory.initElements(dr, EditPostPage.class);
        String title = String.format("Test title %s", UUID.randomUUID());
        editPostPage.createPost(title, "this is content", dr);

        dr.get(buildURL("wp-admin/edit.php"));
        PostListPage postListPage = PageFactory.initElements(dr, PostListPage.class);
        WebElement latestPost = postListPage.getFirstPost();

        assertEquals(title, latestPost.getText());
    }

}
