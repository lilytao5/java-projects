package info.itest.www.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Created by eason on 2017/8/15.
 */
public class LoginPage {
    private By errorMessageLocator = By.id("login_error");

    @FindBy(how = How.ID, using = "user_login")
    private WebElement username;

    @FindBy(id = "user_pass")
    private WebElement password;

    @FindBy(id = "wp-submit")
    private WebElement loginBtn;

    public DashboardPage loginSuccess(String uName, String passwd, WebDriver dr) {
        login(uName, passwd);
        return PageFactory.initElements(dr, DashboardPage.class);
    }

    public void login(String uName, String passwd) {
        username.sendKeys(uName);
        password.sendKeys(passwd);
        loginBtn.click();
    }

    public String loginFailed(String uName, String passwd, WebDriver dr) {
        login(uName, passwd);
        WebDriverWait wait = new WebDriverWait(dr, 5);
        wait.until(ExpectedConditions.visibilityOfElementLocated(errorMessageLocator));
        return dr.findElement(errorMessageLocator).getText().trim();
    }

    public void clear() {
        username.clear();
        password.clear();
    }
}
