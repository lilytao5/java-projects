package info.itest;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

/**
 * Created by eason on 2017/6/19.
 */
public class FeedbackFormTest {
    private static ChromeDriver dr;
    private static final String formUrl = "https://jinshuju.net/f/1kqu5L";

    @BeforeClass
    public static void initBrowser() {
        dr = new ChromeDriver();
        dr.get(formUrl);
    }

    @Test
    public void submitForm() throws InterruptedException {
//        您对我们的服务满意么: 非常满意
        WebElement radioDiv = dr.findElement(By.cssSelector("div[data-api-code=field_9]"));
//        highLight(radioDiv);
        radioDiv.findElement(By.cssSelector(".radio")).click();

//        您最喜欢的部分是: 服务2
        WebElement checkboxDiv = dr.findElement(By.cssSelector("div[data-label=您最喜欢的部分是]"));
        checkboxDiv.findElements(By.className("checkbox")).get(1).click();
        highLight(checkboxDiv);

//        性别: 男
        Select sex = new Select(dr.findElement(By.name("entry[field_12]")));
        sex.selectByVisibleText("男");
//        dr.findElement(By.cssSelector("option[value=JVUg]")).click();

//        建议和联系方式
        dr.findElement(By.name("entry[field_11]")).sendKeys("Hello textarea");
        dr.findElement(By.name("entry[field_8]")).sendKeys(System.currentTimeMillis() + "");

//       提交
        dr.findElement(By.name("commit")).click();

        assertTrue(dr.findElement(By.className("gd-icon-check-circle")).isDisplayed());

    }


    @AfterClass
    public static void closeBrowser() {
        dr.quit();
    }

    private void highLight(WebElement el) {
        dr.executeScript("$(arguments[0]).css('background', 'yellow')", el);
    }
}
