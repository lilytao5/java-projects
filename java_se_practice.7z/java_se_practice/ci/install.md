# 在windows上安装Jenkins

### tomcat流

1. 安装jdk, 最好1.8

2. 安装tomcat服务器, 推荐[tomcat 9](http://tomcat.apache.org/download-90.cgi)

3. 下载jenkins最新版本, [直接点击下载](http://mirrors.jenkins-ci.org/war/latest/jenkins.war )

4. 将下载好的jenkins.war包放到tomcat的webapps目录下

5. 在浏览器中访问[localhost:8080/jenkins](http://localhost:8080/jenkins)

### 另一种方式，jar流

在命令行中运行

```
java -jar jenkins.war

```

浏览器访问 [localhost:8080](http://localhost:8080)，创建初始管理员帐号即可。


### jenkins默认的密码

jenkins默认会保存一份初始密码在``C:\Users\your_username\.jenkins\secrets```中，当你找不到初始密码时不妨去看看。
