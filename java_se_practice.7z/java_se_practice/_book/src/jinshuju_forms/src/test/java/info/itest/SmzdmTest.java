package info.itest;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by eason on 2017/7/11.
 */
public class SmzdmTest {

    private Smzdm zdm;

    @Before
    public void setUp() throws Exception {
        zdm = new Smzdm();
    }

    @After
    public void tearDown() throws Exception {
        zdm.quit();
    }

    @Test
    public void login() throws Exception {
        zdm.login("YourUserName", "YourPassword");
        assertTrue(zdm.userLink().isDisplayed());
    }

    @Test
    public void signUp() throws Exception {
        zdm.login("YourUserName", "YourPassword");
        zdm.signUp();
        assertTrue(zdm.signUpLink().getText().contains("已签到"));
    }

}