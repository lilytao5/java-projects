本章的主要内容是元素定位的强化训练以及css选择器。

selenium可以定位一个元素或一组元素。

* 定位一个元素用的是```findElement```方法，该方法的返回的类型是```WebElement```，具体看[这里](https://github.com/SeleniumHQ/selenium/blob/master/java/client/src/org/openqa/selenium/remote/RemoteWebDriver.java#L401)

* 定位一组元素用的是```findElements```方法，该方法的返回的类型是```List<WebElement>```，具体看[这里](https://github.com/SeleniumHQ/selenium/blob/master/java/client/src/org/openqa/selenium/remote/RemoteWebDriver.java#L397)

我们可以通过下面的一些方式去定位

* [id](https://github.com/SeleniumHQ/selenium/blob/master/java/client/src/org/openqa/selenium/By.java#L51)
* [linkText](https://github.com/SeleniumHQ/selenium/blob/master/java/client/src/org/openqa/selenium/By.java#L63)
* [partialLinkText](https://github.com/SeleniumHQ/selenium/blob/master/java/client/src/org/openqa/selenium/By.java#L75)
* [name](https://github.com/SeleniumHQ/selenium/blob/master/java/client/src/org/openqa/selenium/By.java#L87)
* [tagName](https://github.com/SeleniumHQ/selenium/blob/master/java/client/src/org/openqa/selenium/By.java#L99)
* [xpath](https://github.com/SeleniumHQ/selenium/blob/master/java/client/src/org/openqa/selenium/By.java#L111)
* [className](https://github.com/SeleniumHQ/selenium/blob/master/java/client/src/org/openqa/selenium/By.java#L127)
* [cssSelector](https://github.com/SeleniumHQ/selenium/blob/master/java/client/src/org/openqa/selenium/By.java#L143)

本章会重点关注使用cssSelector的定位方式。
