# css选择器

学习css选择器有如下的一些好处

* 应用广，jquery和一些爬虫系统都支持css选择器
* 语法相对简单
* 定位元素的好帮手，尽管不如xpath强大，但能够满足大部分定位需求
* 顺便学以下前端知识，一举两得

### 目标

学会使用各种css选择器

### 自学内容

建议花费时间: **12小时**

* [基础内容](http://www.w3school.com.cn/css/css_syntax.asp)
* [元素选择器](http://www.w3school.com.cn/css/css_selector_type.asp)
* [分组](http://www.w3school.com.cn/css/css_selector_grouping.asp)
* [id选择器](http://www.w3school.com.cn/css/css_selector_id.asp)
* [类选择器](http://www.w3school.com.cn/css/css_selector_class.asp)
* [属性选择器](http://www.w3school.com.cn/css/css_selector_attribute.asp)
* [后代选择器](http://www.w3school.com.cn/css/css_selector_descendant.asp)
* [子元素选择器](http://www.w3school.com.cn/css/css_selector_child.asp)
